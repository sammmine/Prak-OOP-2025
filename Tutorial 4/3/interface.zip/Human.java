public class Human implements CanWalk, CanTalk {
    public void walk() {
        System.out.println("Human is walking");
    }
    public void talk() {
        System.out.println("Human is talking");
    }
}