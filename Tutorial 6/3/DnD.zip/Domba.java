public class Domba implements Kelas {
    // Menampilkan pesan
    //      "Moooooo"
    public void serang(Karakter self, Karakter target) {
        // self.serang(target);
        System.out.println("Moooooo");
    }

    // Menampilkan pesan
    //     "Mbeeeeeeekk"
    public void gunakanKemampuan(Karakter self, Karakter target) {
        // self.gunakanKemampuan(target);
        System.out.println("Mbeeeeeeekk");
    }

    // Menampilkan pesan
    //      "Mbeeekkk mbeeekkk mbeeekkk"
    public void gunakanUltimate(Karakter self, Karakter target) {
        // self.gunakanUltimate(target);
        System.out.println("Mbeeekkk mbeeekkk mbeeekkk");
    }
}
